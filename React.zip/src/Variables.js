export const variables={
    API_URL: "https://dotnetcoreproj123-begzdyc4dea6hder.koreasouth-01.azurewebsites.net/api/"
}